This TAR file contains the source code for TBMR and 1 already compiled
Linux executable "tbmr". This source code computes the tree-based
Morse regions on the Max-tree and on the Min-tree independently, and
combines both into one file. The resulting file can be used as an
input for SIFT descriptors computation (the executable is available
from
"http://www.robots.ox.ac.uk/~vgg/research/affine/descriptors.html#binaries").

This source code is a small variant of the given algorithm in the
paper. For each critical node having more than one child, we check if
the largest region containing this node without any change of topology
is above its parent, if not, discard this critical node. And note also
that we do not select the critical nodes themselves as final TBMRs.

The compilation of the source code requires the following external
libraries:
Boost
libfreeimage
Intel TBB

And you need a c++ 11 compliant compiler (applications have been
successfully compiled with g++ (Debian 4.7.2-5) 4.7.2.)

EX: g++ -std=c++11 -lfreeimage -ltbb -DNDEBUG -O3 tbmr.cpp -I . -o tbmr

The format of the TBMR output is the same as those detectors available
from "http://www.robots.ox.ac.uk/~vgg/research/affine/detectors.html".

TBMR output

format:
---------------------
1.0
m
u_1 v_1 a_1 b_1 c_1
        .
	.

	.
	.
u_m v_m a_m b_m c_m
---------------------
An TBMR output example: img1.tbmr

u, v, a, b, and c are parameters defining an affine region upon which
the descriptor SIFT is computed.

a(x-u)(x-u)+2b(x-u)(y-v)+c(y-v)(y-v)=1
with (0,0) at image top left corner. (u, v) is the coordinates of the
centroid of a detected TBMR.

An example to compute the tree-based Morse regions:
./tbmr graf1.pgm -o graf1.tbmr
