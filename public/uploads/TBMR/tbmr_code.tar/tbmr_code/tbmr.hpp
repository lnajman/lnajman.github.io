#ifndef TBMR_HPP
# define TBMR_HPP

# include <mln/core/image/image.hpp>
# include <mln/core/image/sub_image.hpp>
# include <mln/core/extension/fill.hpp>
# include <mln/core/algorithm/sort_indexes.hpp>
# include <mln/core/wrt_offset.hpp>
# include <mln/io/imprint.hpp>

# include <fstream>
# include <ostream>
# include <sstream>

namespace mln
{

  namespace morpho
  {

    namespace internal
    {
      static
      inline
      std::size_t
      zfindroot(image2d<unsigned>& parent, std::size_t p)
      {
        if (parent[p] == p)
          return p;
        else
          return parent[p] = zfindroot(parent, parent[p]);
      }

    }

    //for incrementatal computation of region information
    struct attribute{
      unsigned area;
      std::size_t sum_x = 0;
      std::size_t sum_y = 0;
      std::size_t sum_xy = 0;
      std::size_t sum_xx = 0;
      std::size_t sum_yy = 0;
    };

    template <typename V, typename Neighborhood, typename StrictWeakOrdering = std::less<V> >
    unsigned
    tbmr_extraction (const image2d<V>& ima, const Neighborhood& nbh,
		     unsigned minimumSize, double maximumRelativeSize,
		     std::ostringstream& outputFile,
		     StrictWeakOrdering cmp = StrictWeakOrdering())
    {

      //construct the Max/Min-tree based on union-find [Berger 2007 ICIP] + rank
      //and compute incrementally the moments information during tree construciton
      //--------------------------------------------------------------------------
      image2d<unsigned> parent, zpar, root;
      image2d<unsigned> rank;
      image2d<bool> dejaVu;
      image2d<attribute> imaAttribute ;

      resize(parent, ima);
      resize(zpar, ima);
      resize(root, ima);
      resize(rank, ima, ima.border(), 0);
      resize(dejaVu, ima, ima.border(), false);
      resize(imaAttribute, ima);

      extension::fill(dejaVu, false);

      //sort the pixels in increasing or decreasing order
      std::vector<unsigned> S = sort_indexes(ima, cmp);
      auto offsets = wrt_delta_index(ima, nbh.dpoints);

      for (int i = S.size()-1; i >= 0; --i)
      {
	std::size_t p = S[i];
	// make set
	{
	  parent[p] = p;
	  zpar[p] = p;
          root[p] = p;
	  dejaVu[p] = true;
	  imaAttribute[p].area = 1;
	  point2d point_p = ima.point_at_index(p);
	  imaAttribute[p].sum_x = point_p[0];
	  imaAttribute[p].sum_y = point_p[1];
	  imaAttribute[p].sum_xy = point_p[0]*point_p[1];
	  imaAttribute[p].sum_xx = point_p[0]*point_p[0];
	  imaAttribute[p].sum_yy = point_p[1]*point_p[1];
	}

        std::size_t x = p; // zpar of p
	for (unsigned k = 0; k < offsets.size(); ++k)
	{
	  std::size_t q = p + offsets[k];
	  if (dejaVu[q])
	  {
	    std::size_t r = internal::zfindroot(zpar, q);
	    if (r != x) // make union
	    {
	      parent[root[r]] = p;
	      //accumulate information
	      imaAttribute[p].area += imaAttribute[root[r]].area;
	      imaAttribute[p].sum_x += imaAttribute[root[r]].sum_x;
	      imaAttribute[p].sum_xx += imaAttribute[root[r]].sum_xx;
	      imaAttribute[p].sum_xy += imaAttribute[root[r]].sum_xy;
	      imaAttribute[p].sum_y += imaAttribute[root[r]].sum_y;
	      imaAttribute[p].sum_yy += imaAttribute[root[r]].sum_yy;

	      if (rank[x] < rank[r])
	      {
		//we merge p to r
		zpar[x] = r;
		root[r] = p;
		x = r;
	      }
	      else if (rank[r] < rank[p])
	      {
		// merge r to p
		zpar[r] = p;
	      }
	      else
	      {
		// same height
		zpar[r] = p;
		rank[p] += 1;
	      }
	    }
	  }
	}
      }
      //end of Min/Max-tree construciton
      //--------------------------------------------------------------------------

      // canonization
      for (std::size_t p: S)
      {
	std::size_t q = parent[p];
	if (ima[parent[q]] == ima[q])
	  parent[p] = parent[q];
      }


      //TBMRs extraction

      /* small variant of the given algorithm in the paper. For each
	critical node having more than one child, we check if the
	largest region containing this node without any change of
	topology is above its parent, if not, discard this critical
	node */

      /* note also that we do not select the critical nodes themselves
       * as final TBMRs */

      //--------------------------------------------------------------------------
      image2d<unsigned> numSons;
      resize(numSons, ima, ima.border(), 0);
      std::vector<unsigned> vecNodes(imaAttribute[S[0]].area);
      unsigned numNodes = 0;

      //leaf to root propagation to select the canonized nodes
      for (int i = S.size()-1; i >= 0; --i)
      {
	std::size_t p = S[i];
	if(parent[p] == p || ima[p] != ima[parent[p]])
	{
	  vecNodes[numNodes++] = p;
	  if(imaAttribute[p].area >= minimumSize)
	    numSons[parent[p]]++;
	}
      }

      image2d<bool> isSeen;
      resize(isSeen, ima, ima.border(), false);

      //parent of critical leaf node
      image2d<bool> isParentofLeaf;
      resize(isParentofLeaf, ima, ima.border(), false);
      for (int i = 0; i < vecNodes.size(); i++)
      {
      	std::size_t p = vecNodes[i];
      	if(numSons[p] == 0 && numSons[parent[p]] == 1)
      	  isParentofLeaf[parent[p]] = true;
      }

      unsigned maxArea = maximumRelativeSize*S.size();
      unsigned numTbmrs = 0;

      std::vector<unsigned> vecTbmrs(numNodes);
      for (int i = 0; i < vecNodes.size(); i++)
      {
      	std::size_t p = vecNodes[i];
      	if(numSons[p] == 1 && !isSeen[p] && imaAttribute[p].area <= maxArea)
      	{
      	  unsigned num_ancestors = 0;
      	  std::size_t pt = p;
      	  std::size_t po = pt;
	  while(numSons[pt] == 1 && imaAttribute[pt].area <= maxArea)
      	  {
      	    isSeen[pt] = true;
      	    num_ancestors++;
      	    po = pt;
      	    pt = parent[pt];
      	  }
      	  if(!isParentofLeaf[p] || num_ancestors > 1)
      	  {
      	    vecTbmrs[numTbmrs++] = po;
      	  }
      	}
      }
      //end of TBMRs extraction
      //------------------------------------------------------------------------

      //compute best fitting ellipses
      //------------------------------------------------------------------------
      unsigned num_valid_TBMRs = 0;
      for (int i = 0; i < numTbmrs; i++)
      {
	std::size_t p = vecTbmrs[i];
	double x = (double)imaAttribute[p].sum_x / (double)imaAttribute[p].area;
	double y = (double)imaAttribute[p].sum_y /( double)imaAttribute[p].area;
	double i20 = imaAttribute[p].sum_xx - imaAttribute[p].area*x*x;
	double i02 = imaAttribute[p].sum_yy - imaAttribute[p].area*y*y;
	double i11 = imaAttribute[p].sum_xy - imaAttribute[p].area*x*y;
	double n = i20*i02 - i11*i11;
	if(n != 0)
	{
	  double a = i02/n;
	  a = a*(imaAttribute[p].area-1)/4;
	  double b = -i11/n;
	  b = b*(imaAttribute[p].area-1)/4;
	  double c = i20/n;
	  c = c*(imaAttribute[p].area-1)/4;

	  //filter out some non meaingful ellipses
	  double a1 = a;
	  double b1 = b;
	  double c1 = c;
	  unsigned ai = 0;
	  unsigned bi = 0;
	  unsigned ci = 0;
	  if(a > 0)
	  {
	    ai = 100000*a;
	    if(a < 0.00005)
	      a1 = 0;
	    else if(a < 0.0001)
	    {
	      a1 = 0.0001;
	    }
	    else
	    {
	      ai = 10000*a;
	      a1 = (double)ai/10000;
	    }
	  }
	  else
	  {
	    if(a > - 0.00005)
	      a1 = 0;
	    else if(a > - 0.0001)
	      a1 = -0.0001;
	    else
	    {
	      ai = 10000*(-a);
	      a1 = -(double)ai/10000;
	    }
	  }

	  if(b > 0)
	  {
	    bi = 100000*b;
	    if(b < 0.00005)
	      b1 = 0;
	    else if(b < 0.0001)
	    {
	      b1 = 0.0001;
	    }
	    else
	    {
	      bi = 10000*b;
	      b1 = (double)bi/10000;
	    }
	  }
	  else
	  {
	    if(b > - 0.00005)
	      b1 = 0;
	    else if(b > - 0.0001)
	      b1 = -0.0001;
	    else
	    {
	      bi = 10000*(-b);
	      b1 = -(double)bi/10000;
	    }
	  }

	  if(c > 0)
	  {
	    ci = 100000*c;
	    if(c < 0.00005)
	      c1 = 0;
	    else if(c < 0.0001)
	    {
	      c1 = 0.0001;
	    }
	    else
	    {
	      ci = 10000*c;
	      c1 = (double)ci/10000;
	    }
	  }
	  else
	  {
	    if(c > - 0.00005)
	      c1 = 0;
	    else if(c > - 0.0001)
	      c1 = -0.0001;
	    else
	    {
	      ci = 10000*(-c);
	      c1 = -(double)ci/10000;
	    }
	  }
	  double v = (a1 + c1 - std::sqrt(a1*a1+c1*c1+4*b1*b1-2*a1*c1))/2;

	  double l1 = (a + c + std::sqrt(a*a+c*c+4*b*b-2*a*c))/2;
	  double l2 = (a + c - std::sqrt(a*a+c*c+4*b*b-2*a*c))/2;
	  l1 = std::sqrt(l1);
	  l2 = std::sqrt(l2);
	  l1 = 1/l1;
	  l2 = 1/l2;
	  double l = std::min(l1, l2);

	  if(l >= 1.5 && v != 0)
	  {
	    num_valid_TBMRs++;
	    outputFile << y << " " << x << " " << c << " " << b << " " << a << std::endl;
	  }
	}
      }
      //---------------------------------------------
      return num_valid_TBMRs;
    } //end of tbmr_extraction

  } //end of name space mln:morpho

} //end of namespace mln

#endif // !TBMR__HPP
