#include <mln/core/image/image2d.hpp>
#include <mln/core/neighb2d.hpp>
#include <mln/io/imread.hpp>
#include <mln/core/grays.hpp>
#include "tbmr.hpp"
# include <fstream>
#include <ostream>

void usage(char* argv[])
{
  std::cout << "usage: " << argv[0] << " in.pgm [options]" << std::endl
	    << "-ms (30) [30] minimum size" << std::endl
	    << "-per (0.01) [0.01] maximum relative area" << std::endl
	    << "-o (out.tbmr) [out.tbmr] output file" << std::endl;
  std::abort();
}

int main(int argc, char** argv)
{
  if(argc < 2)
    usage(argv);
  using namespace mln;
  const char* filename = argv[1];

  //read pgm input
  image2d<uint8> ima;
  io::imread(filename, ima);

  unsigned minimumSize = 30;
  double maximumRelativeSize = 0.01;

  std::string outputFile = "out.tbmr";

  unsigned last_arg = argc - 1, i = 2;
  while (i < argc)
  {
    std::string s = argv[i];
    if (s == "-ms")
    {
      if (i == last_arg)
      {
	std::cout << "you have to specify the minimum size after -ms" << std::endl;
	std::abort();
      }
      minimumSize = atoi(argv[i + 1]);
    }
    else if (s == "-per")
    {
      if (i == last_arg)
      {
	std::cout << "you have to specify the maximum relative size after -per" << std::endl;
	std::abort();
      }
      maximumRelativeSize = std::atof(argv[i + 1]);
    }
    else if (s == "-o")
    {
      if (i == last_arg)
      {
	std::cout << "you have to specify the name of the output file after -o" << std::endl;
	std::abort();
      }
      outputFile = argv[i+1];
    }
    else
      usage(argv);
    i += 2; // next couple of args
  }

  std::ostringstream oss(std::ostringstream::out);

  //TBMRs extraction on Max-tree
  unsigned numMax = morpho::tbmr_extraction(ima, c4, minimumSize, maximumRelativeSize, oss, std::less<uint8> ());
  std::cout << "number of TBMRs on the Max-tree = " << numMax << std::endl;

  //TBMRs extraction on Min-tree
  unsigned numMin = morpho::tbmr_extraction(ima, c4, minimumSize, maximumRelativeSize, oss, std::greater<uint8> ());
  std::cout << "number of TBMRs on the Min-tree = " << numMin << std::endl;

  unsigned numTBMRs = numMax + numMin;
  std::cout << "total number of TBMRs = " << numTBMRs << std::endl;
  std::ofstream file(outputFile);
  double t = 1.0;
  file << t << std::endl;
  file << numTBMRs << std::endl;
  file << oss.str() << std::endl;
}
