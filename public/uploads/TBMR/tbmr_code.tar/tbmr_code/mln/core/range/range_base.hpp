#ifndef MLN_CORE_RANGE_RANGE_BASE_HPP
# define MLN_CORE_RANGE_RANGE_BASE_HPP

namespace mln
{

  template <typename Derived>
  struct range_base
  {


  };

}

#endif // ! MLN_CORE_RANGE_RANGE_BASE_HPP
