#ifndef MLN_CORE_INTENRAL_NESTED_LOOP_ITERATOR_HPP
# define MLN_CORE_INTERNAL_NESTED_LOOP_ITERATOR_HPP

# include <mln/core/iterator/iterator_base.hpp>

namespace mln
{

  namespace details
  {
    struct no_op_policy;

    template <typename Vec>
    struct identity_spolicy;
  }

  /// \brief Implement an iterator that has the semantic:
  /// p is a vector of type Vec
  /// s is an auxiliary, optional structure
  /// \code
  /// initialize(s)
  /// for (init<0>(p); !finished<0>(p); next<0>(p), next<0>(s))
  ///    for (init<1>(p); !finished<1>(p); next<1>(p), next<1>(s))
  ///    .
  ///      .
  ///        yield
  /// \endcode
  ///
  template <class Vec,
	    class IterationPolicy,
	    class Structure = Vec,
	    class StructureIntrusionPolicy = details::identity_spolicy<Vec> >
  struct __nested_loop_iterator;

  template <class Vec,
	    class IterationPolicy,
	    class Structure,
	    class DerefencePolicy,
	    class ValueIntrusionPolicy,
	    class IndexIntrusionPolicy>
  struct __nested_loop_pixel_iterator;

  /// \defgroup structure_policy
  /// * SP::deref_value_type
  /// * SP::deref_reference
  /// * SP::initialize(Structure&) const
  /// * SP::next<n>(Structure&) const
  /// * Vec&		SP::get_vec(Structure&) const
  /// * const Vec&	SP::get_vec(const Structure&) const
  /// * ... SP::deref(const Structure&) const
  /// \{
  namespace details
  {
    template <class Pixel,
	      class DerefencePolicy,
	      class ValueIntrusionPolicy,
	      class IndexIntrusionPolicy>
    struct pixel_spolicy;

    template <typename Vec>
    struct identity_spolicy;
  }
  /// \}

  /// \defgroup iteration_policies
  /// * `PVis::initialize(Vec&) const`
  /// * `PVis::init<n>(Vec&) const`
  /// * `PVis::next<n>(Vec&) const`
  /// * `PVis::finished<n>(const Vec&) const`
  /// \{
  template <typename Vec, bool openbounded = true> struct __iterate_to;
  template <typename Vec, bool openbounded = true> struct __iterate_from_to;
  template <typename Vec, bool openbounded = true> struct __iterate_from_to_step;
  template <typename Vec, bool openbounded = true> struct __iterate_from_down;
  template <typename Vec, bool openbounded = true> struct __iterate_from_downto;
  template <typename Vec, bool openbounded = true> struct __iterate_from_downto_step;
  /// \}



  /******************************/
  /***  Impementation        ****/
  /******************************/

  /******************************/
  /*** Structure Policies     ***/
  /******************************/

  namespace details
  {
    struct no_op_policy
    {
      template <typename T>
      void initialize(T) const {}

      template <size_t n, typename T> void next (T) const {}
    };


    template <typename Vec>
    struct identity_spolicy
    {
      typedef Vec	 deref_value_type;
      typedef const Vec& deref_reference;

      void initialize(Vec&) const {}
      template <unsigned n> void next(Vec&) {}
      Vec& get_vec(Vec& v) { return v; }
      const Vec& get_vec(const Vec& v) const { return v; }
      const Vec& deref(const Vec& v) const { return v; }

    };

    template <class Pixel,
	      class DereferencePolicy,
	      class ValueIntrusionPolicy,
	      class IndexIntrusionPolicy>
    struct pixel_spolicy
    {
      typedef typename DereferencePolicy::template with <Pixel>::reference	deref_reference;
      typedef typename DereferencePolicy::template with <Pixel>::value_type	deref_value_type;

      pixel_spolicy() = default;

      pixel_spolicy(const ValueIntrusionPolicy& vp,
		    const IndexIntrusionPolicy& ip)
	: m_vp (vp), m_ip(ip)
      {
      }

      void initialize(Pixel& s)
      {
	m_vp.initialize(this->get_value(s));
	m_ip.initialize(this->get_index(s));
      }

      template <unsigned n>
      void next(Pixel& s)
      {
	m_vp.template next<n>(this->get_value(s));
	m_ip.template next<n>(this->get_index(s));
      }


      typename Pixel::point_type&
      get_vec(Pixel& s)
      {
	return this->get_point(s);
      }

      const typename Pixel::point_type&
      get_vec(const Pixel& s) const
      {
	return this->get_point(s);
      }

      deref_reference
      deref(const Pixel& s) const
      {
	return DereferencePolicy::deref(s);
      }

    private:
      ValueIntrusionPolicy m_vp;
      IndexIntrusionPolicy m_ip;
    };

    template <class Pixel, class DereferencePolicy, class ValueIntrusionPolicy>
    struct pixel_spolicy<Pixel, DereferencePolicy, ValueIntrusionPolicy, no_op_policy>
    {
      typedef typename DereferencePolicy::template with<Pixel>::reference	deref_reference;
      typedef typename DereferencePolicy::template with<Pixel>::value_type	deref_value_type;

      pixel_spolicy(const ValueIntrusionPolicy& vp, no_op_policy)
	: m_vp (vp)
      {
      }

      void initialize(Pixel& s)
      {
	m_vp.initialize(this->get_value(s));
      }

      template <unsigned n>
      void next(Pixel& s)
      {
	m_vp.template next<n>(this->get_value(s));
      }

      typename Pixel::point_type&
      get_vec(Pixel& s)
      {
	return this->get_point(s);
      }

      const typename Pixel::point_type&
      get_vec(const Pixel& s) const
      {
	return this->get_point(s);
      }

      deref_reference
      deref(const Pixel& s) const
      {
	return DereferencePolicy::deref(s);
      }

    private:
      ValueIntrusionPolicy m_vp;
    };


  }


  /******************************/
  /*** Iteration Policies     ***/
  /******************************/


  template <typename Vec>
  struct __iterate_to<Vec, true>
  {
    __iterate_to() = default;
    constexpr __iterate_to(const Vec& to) : m_to (to) {}

    void initialize(Vec& v) { v = literal::zero; }
    template <unsigned n> void init(Vec& v) const { v[n] = 0; }
    template <unsigned n> void next(Vec& v) const { ++v[n]; }
    template <unsigned n> bool finished(const Vec& v) const { return v[n] >= m_to[n]; }

  private:
    const Vec m_to;
  };

  template <typename Vec>
  struct __iterate_from_to<Vec, true>
  {
    __iterate_from_to() = default;
    constexpr __iterate_from_to(const Vec& from, const Vec& to)
      : m_from(from), m_to (to) {}

    void initialize(Vec& v) { v = m_from; }
    template <unsigned n> void init(Vec& v) const { v[n] = m_from[n]; }
    template <unsigned n> void next(Vec& v) const { ++v[n]; }
    template <unsigned n> bool finished(const Vec& v) const
    {
      return v[n] >= m_to[n];
    }

  private:
    const Vec m_from;
    const Vec m_to;
  };

  template <typename Vec>
  struct __iterate_from_to<Vec, false>
  {
    __iterate_from_to() = default;
    constexpr __iterate_from_to(const Vec& from, const Vec& to)
      : m_from(from), m_to (to) {}

    void initialize(Vec& v)
    {
      v = m_from;
      m_bitset = (1 << (Vec::ndim + 1)) - 1;
    }

    template <unsigned n> void init(Vec& v)
    {
      v[n] = m_from[n];
      m_bitset |= (1 << n);
    }

    template <unsigned n> void next(Vec& v)
    {
      ++v[n];
      m_bitset &= ~(1 << n);
    }

    template <unsigned n> bool finished(const Vec& v) const
    {
      auto x = v[n];
      return --x >= m_to[n] and !(m_bitset & (1 << n));
    }

  private:
    const Vec m_from;
    const Vec m_to;
    int m_bitset;
  };



  template <typename Vec, bool openbounded>
  struct __iterate_from_to_step
  {
    __iterate_from_to_step() = default;
    constexpr __iterate_from_to_step(const Vec& from, const Vec& to, const Vec& step)
      : m_from(from), m_to (to), m_step (step)
    {
    }

    void initialize(Vec& v) { v = m_from; }
    template <unsigned n> void init(Vec& v) const { v[n] = m_from[n]; }
    template <unsigned n> void next(Vec& v) const { v[n] += m_step[n]; }
    template <unsigned n> bool finished(const Vec& v) const
    {
      return openbounded ? (v[n] >= m_to[n]) : (v[n] > m_to[n]);
    }

  private:
    const Vec m_from;
    const Vec m_to;
    const Vec m_step;
  };


  /******************************/
  /*** Nested Loop Iterator   ***/
  /******************************/

  template <class Vec,
	    class IterationPolicy,
	    class Structure,
	    class StructureIntrusionPolicy >
  struct __nested_loop_iterator
    : iterator_base< __nested_loop_iterator<Vec, IterationPolicy, Structure, StructureIntrusionPolicy>,
		     typename StructureIntrusionPolicy::deref_value_type,
		     typename StructureIntrusionPolicy::deref_reference>
  {
    typedef typename StructureIntrusionPolicy::deref_reference reference;

    __nested_loop_iterator(Structure s,
			   const IterationPolicy& ip,
			   const StructureIntrusionPolicy& sp = StructureIntrusionPolicy())
      : m_s (s), m_ip (ip), m_sp (sp)
    {
    }

    __nested_loop_iterator() = default;

    void init()
    {
      m_sp.initialize(m_s);
      m_ip.initialize(vec());
    }

    void next()
    {
      this->next_<ndim-1>();
    }


    bool finished() const
    {
      return m_ip.template finished<0>(vec());
    }

    reference
    dereference() const
    {
      return m_sp.deref(m_s);
    }


  private:
    enum { ndim = Vec::ndim };

    template <unsigned n>
    typename std::enable_if<(n > 0), void>::type
    next_()
    {
      mln_precondition(not this->finished());
      m_ip.template next<n>(vec());
      if (not m_ip.template finished<n>(vec()))
	{
	  m_sp.template next<n>(m_s);
	  return;
	}
      this->next_<n-1>();
      m_ip.template init<n>(vec());
    }

    template <size_t n>
    typename std::enable_if<n == 0, void>::type
    next_()
    {
      mln_precondition(not this->finished());
      m_ip.template next<0>(vec());
      m_sp.template next<0>(m_s);
    }

    Vec& vec() { return m_sp.get_vec(m_s); }
    const Vec& vec() const { return m_sp.get_vec(m_s); }

  private:
    Structure m_s;
    IterationPolicy m_ip;
    StructureIntrusionPolicy m_sp;
  };

}

#endif // ! MLN_CORE_INTERNAL_NESTED_LOOP_ITERATOR_HPP
