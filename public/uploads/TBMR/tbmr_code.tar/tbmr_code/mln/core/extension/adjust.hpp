#ifndef MLN_CORE_EXTENSION_ADJUST_HPP
# define MLN_CORE_EXTENSION_ADJUST_HPP

# include <mln/core/image/image.hpp>

namespace mln
{

  namespace extension
  {

    template <typename I, typename N>
    /* unspecified */
    auto adjust(const Image<I>& ima, const N& nbh)
      -> decltype(impl::adjust(ima, nbh));

    template <typename I, typename N>
    /* unspecified */
    auto adjust(Image<I>& ima, const N& nbh)
      -> decltype(impl::adjust(ima, nbh));



    /*******************/
    /** Implementation */
    /*******************/

    namespace impl
    {

      template <typename I>
      
      adjust(const I& ima, const N& nbh, std::true_type has_extension)
      {
	
      }

      template <typename I>
      extended_image<I>
      adjust(I& ima, const N& nbh, std::false_type has_extension)
      {


      }

    }


    template <typename I, typename N>
    auto adjust(const Image<I>& ima, const N& nbh)
      -> decltype(impl::adjust(ima, nbh))
    {
      return impl::adjust(ima, nbh);
    }

    template <typename I, typename N>
    auto adjust(Image<I>& ima, const N& nbh)
      -> decltype(impl::adjust(ima, nbh))
    {
      return impl::adjust(ima, nbh);
    }



  }

}

#endif // ! MLN_CORE_EXTENSION_ADJUST_HPP
