#ifndef MLN_CORE_IMAGE_MORPHERS_ZIP_IMAGE_SPE_HPP
# define MLN_CORE_IMAGE_MORPHERS_ZIP_IMAGE_SPE_HPP


namespace mln
{

  // FWD declaration
  template <typename T, unsigned dim, typename E>
  struct ndimage_base;

  template <typename T>
  struct image2d;

  // Specialization
  // FIXME: to fix when image2d/image3d... will alias ndimage
  template <unsigned dim, typename... E>
  struct zip_image< ndimage_base<typename E::value_type, dim, E>... >;

  template <typename T, unsigned dim>
  struct zip_image< image2d<T, dim> >;



  /***********************************/
  /** Specialization for ndimage   ***/
  /***********************************/

  template <unsigned dim, typename... E>
  struct zip_image< ndimage_base<typename E::value_type, dim, E>... > : morpher_base<
    zip_image<E...>,
    typename std::tuple_element<0, std::tuple<Images...> >::type,
    typename std::remove_reference<typename std::tuple_element<0, std::tuple<Images...> >::type>::type::point_type,
    std::tuple<typename std::decay<mln_reference(Images)>::type...>
    >
  {
    static_assert(sizeof... (Images) >= 2, "You must zip at least two images.");

  private:
    typedef zip_image<E...> this_t;
    typedef typename std::tuple_element<0, std::tuple<Images...> >::type	first_image_;
    typedef typename std::remove_reference<first_image_>::type			I0;

    typedef std::tuple<mln_vrange(Images)...>						vrange_tuple;
    typedef std::tuple<mln_cvrange(Images)...>						cvrange_tuple;
    typedef std::tuple<mln_pixrange(Images)...>						pixrange_tuple;
    typedef std::tuple<mln_cpixrange(Images)...>					cpixrange_tuple;
    typedef std::tuple<typename range_reference<mln_pixrange(Images)>::type...>		pixel_tuple;
    typedef std::tuple<typename range_reference<mln_cpixrange(Images)>::type...>	cpixel_tuple;

    friend struct mln::morpher_core_access;

  public:
    struct pixel_type;
    struct const_pixel_type;

  public:
    typedef typename std::tuple<Images...>					images_type;
    typedef images_type								image_tuple_t;

    typedef mln_point(I0)							point_type;
    typedef typename I0::domain_type						domain_type;
    typedef std::tuple<mln_reference(Images)...>				reference;
    typedef std::tuple<mln_creference(Images)...>				const_reference;
    typedef std::tuple<typename std::decay<mln_reference(Images)>::type...>	value_type;

    struct									value_range;
    struct									const_value_range;
    struct									pixel_range;
    struct									const_pixel_range;

  };



  namespace internal
  {

    /// \brief Encapsulate \p n pointers from images with \p ndim dimensions
    template <unsigned n, unsigned ndim, typename DifferenceType = std::ptrdiff_t>
    struct strided_tuple_pointer_value_visitor
    {
      typedef char* byte_ptr_t;
      enum { ndim = dim };

      strided_pointer_value_visitor() = default;

      strided_pointer_value_visitor(byte_ptr_t start[],
				    std::array<DifferenceType, dim> delta_offsets[])
	: m_init_ptr(start),
	  m_delta_offsets(delta_offsets)
      {
	std::copy(start, start+n, m_init_ptr);
	std::copy(delta_offsets, delta_offsets+n, m_delta_offsets);
      }

      void initialize(byte_ptr_t ptr[])
      {
	std::copy(m_init_ptr, m_init_ptr + n, ptr);
      }

      template <size_t i>
      void next(byte_ptr_t ptr[])
      {
	for (int k = 0; k < n; ++k)
	  ptr[k] += m_delta_offsets[k][i];
      }

    private:
      byte_ptr_t			m_init_ptr[n];
      std::array<DifferenceType, dim>	m_delta_offsets[n];
    };


    /*****************************/
    /** Pixel Implementation    **/
    /*****************************/

    template <unsigned dim, typename... NDImages>
    struct zip_image_pixel
    {
    private:
      enum { n = sizeof...(NDImages) };



    private:
      
    };

  }




  template <unsigned dim, typename... Images>
  struct zip_image< ndimage_base<typename Images::value_type, dim, Images>... >::value_range
  {
    typedef std::tuple<Images...>			images_tuple_t;
    typedef typename std::element<0, tuple_t>::type	I0;
  };


  struct zip_range< std::tuple<ndimage_value_range<Images, typename Images::value_type>...> >
  {
  private:
    typedef std::tuple<Images...>			images_tuple_t;
    typedef typename std::element<0, tuple_t>::type	I0;

    enum { ndim = I0::point_type::ndim };

    template <typename J, typename V>
    friend struct ndimage_value_range;

  public:



  };


}

#endif // ! MLN_CORE_IMAGE_MORPHERS_ZIP_IMAGE_SPE_HPP
