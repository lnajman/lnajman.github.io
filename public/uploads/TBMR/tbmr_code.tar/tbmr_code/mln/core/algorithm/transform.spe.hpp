#ifndef TRANSFORM_SPE_HPP
# define TRANSFORM_SPE_HPP

namespace mln
{

  // Specialization for ndimage when morphing to pointer to member
  template <typename, unsigned, typename> struct ndimage_base;

  template <typename T, unsigned dim, typename E, typename V>
  ndimage<V, dim>
  lazy_transform(ndimage_base<T, dim, E>&& input, V T::* pm);

  template <typename T, unsigned dim, typename V>
  ndimage<V, dim>
  lazy_transform(ndimage_base<T, dim, E>& input, V T::* pm);

  template <typename T, unsigned dim, typename V>
  ndimage<V, dim>
  lazy_transform(const ndimage_base<T, dim, E>& input, V T::* pm);



  /**************************/
  /** Implementation        */
  /**************************/

  template <typename T, unsigned dim, typename V>
  ndimage<V, dim>
  lazy_transform(const ndimage_base<T, dim>& input, V T::* pm)
  {



  }

}

#endif // ! TRANSFORM_SPE_HPP
