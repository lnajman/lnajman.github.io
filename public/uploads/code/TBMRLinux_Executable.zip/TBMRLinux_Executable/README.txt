This ZIP file contains a 64-bit Linux executable "tbmr". This executable
computes the tree-based Morse regions on the Max-tree and on the
Min-tree independently, and combines both into one file. The resulting
file can be used as an input for SIFT descriptors computation (the
executable is available from
"http://www.robots.ox.ac.uk/~vgg/research/affine/descriptors.html#binaries").

The format of the TBMR output is the same as those detectors available
from "http://www.robots.ox.ac.uk/~vgg/research/affine/detectors.html".

TBMR output

format:
---------------------
1.0
m
u_1 v_1 a_1 b_1 c_1
        .
	.

	.
	.
u_m v_m a_m b_m c_m
---------------------
An TBMR output example: img1.tbmr

u, v, a, b, and c are parameters defining an affine region upon which
the descriptor SIFT is computed.

a(x-u)(x-u)+2b(x-u)(y-v)+c(y-v)(y-v)=1
with (0,0) at image top left corner. (u, v) is the coordinates of the
centroid of a detected TBMR.

An example to compute the tree-based Morse regions:
./tbmr img1.pgm img1.tbmr
